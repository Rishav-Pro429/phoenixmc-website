import Alpine from "alpinejs";
// import toc from "./toc.js";
//
// toc();

window.Alpine = Alpine;
Alpine.start();