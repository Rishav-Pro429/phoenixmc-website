// Import the tailwindcss module
const config = {
    theme: {
        extend: {
            screens: {
                "xs": "375px",
            },
            keyframes: {
                levitate: {
                    "0%": {transform: "translateY(0px)"},
                    "50%": {transform: "translateY(-10px)"},
                    "100%": {transform: "translateY(0px)"},
                },
                pulsate: {
                    "0%": {transform: "scale(1)"},
                    "50%": {transform: "scale(1.03)"},
                    "100%": {transform: "scale(1)"},
                }
            },
            animation: {
                levitating: "levitate 2s ease-in-out infinite",
                pulsating: "pulsate 2s ease-in-out infinite",
            },
            fontFamily: {
                body: ["Montserrat", "sans-serif"],
            },
            colors: {
                neutral: {
                    400: "hsl(var(--clr-neutral-400) / <alpha-value>)",
                },
                primary: {
                    DEFAULT: "var(--primary)",
                    light: "var(--primary-light)",
                    dark: "var(--primary-dark)",
                },
                secondary: {
                    DEFAULT: "var(--secondary)",
                    light: "var(--secondary-light)",
                    dark: "hsla(var(--complementary-color) var(--saturation) calc(var(--lightness) * 1.15) / <alpha-value>)",
                },
                element: {
                    DEFAULT: "var(--element)",
                    light: "var(--element-light)",
                    dark: "var(--element-dark)",
                    darker: "var(--element-darker)",
                },
                surface: {
                    DEFAULT: "var(--surface)",
                    "85": "var(--surface-85)",
                    light: "var(--surface-light)",
                    dark: "var(--surface-dark)",
                    darker: "var(--surface-darker)",
                    fade: "var(--surface-fade)",
                },
                complementary: {
                    DEFAULT: "var(--complementary)",
                    "fade": "var(--complementary-fade)",
                },
                "brand-color": "var(--brand-color)",
                "border-color": "var(--border-color)",
                "border-color-accent": "var(--border-color-accent)",
                "button-text": "var(--button-text)",
            },
            dropShadow: {
                header_button: "0px 0px 5px var(--brand-color)",
            },
            boxShadow: {
                featured_post: "inset 0px 0px 5px hsl(var(--clr-primary-400))",
            },
            gridTemplateColumns: {
                "auto-fit-cards": "repeat(auto-fill, minmax(400px, 1fr))",
                "large-card": "0.7fr 1fr",
                "staff": "0.35fr 1fr",
                "staff-cards": "repeat(auto-fill, minmax(180px, 1fr))",
                "vote-with-board": "0.45fr 1fr 0.45fr",
                "vote-without-board": "0.4fr 1fr"
            },
            typography: ({theme}) => ({
                deluxe: {
                    css: {
                        '--tw-prose-body': theme('colors.element[darker]'),
                        '--tw-prose-bullets': theme('colors.brand-color'),
                        '--tw-prose-hr': theme('colors.border-color'),
                        '--tw-prose-captions': theme('colors.element[dark]'),
                    },
                },
            })
        },
    },
    safelist: [
        "animate-levitating",
        "animate-pulsating"
    ],
    plugins: [
        require("@tailwindcss/typography"),
    ],
    content: ["**/*.css", "**/*.hbs", "assets/js/*.js"],
};

// Export the configuration object as the default export
module.exports = config;
